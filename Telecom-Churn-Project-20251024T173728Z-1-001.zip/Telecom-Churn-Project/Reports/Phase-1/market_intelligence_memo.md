# Market Intelligence Memo

## Observations
- Market Saturation: Strong subscriber growth from 2009-2018 has now flattened, suggesting the market is maturing.
- Jio's Disruption: Reliance Jio's entry in 2016 dramatically altered the market, leading to its rapid dominance.
- Competitive Shifts: Jio and Bharti Airtel are the dominant players, while others like Vodafone Idea and BSNL show decline.
- Key Markets: Subscriber distribution is uneven, with Uttar Pradesh (East) and Maharashtra being the top regional circles.
- **Data Anomalies: The data shows extreme spikes and drops, likely due to quality issues that require investigation.

## Open Questions
- Are the sudden subscriber spikes and drops real events or data reporting errors?
- What was the quantifiable impact of Jio's launch on its main competitors?
- What factors are driving the decline of BSNL's subscriber base?
