# Data Integrity Log

File: year-month-circle-and-service-provider-wise-number-of-subscriptions-to-wireline-and-wireless-telecom-services-in-india.csv
Size (bytes): 5464437
Rows: 70728
Checksum: 3c95c4384a27eff8f18ff622b28a5c29

File: metadata.csv
Size (bytes): 578
Rows: 9
Checksum: 325609ca3078269069a116d7e9cb6ad8

