
# Feature Validation Report

## a) Missingness
- All missing values in `value` handled via interpolation + mean filling → now 0 missing.
- Engineered features (`roll_mean`, `trend_slope_12`, lags) have NaN at the start of each series (expected).
- No leakage features included (all lagged).

## b) Distributions
- `pct_change`: Centered around 0, long left tail (steep declines).
- `market_share`: Skewed; top operators hold dominant shares, long tail of small players.
- `rank_in_circle`: Mostly 1–3 ranks matter, tail ranks minor players.
- `hhi_index`: High in rural/small circles (concentrated), lower in metros (competitive).

## c) Correlations
- `market_share` ↔ `rank_in_circle`: Strongly correlated (expected).
- `pct_change` moderately correlated with `churn_flag`.
- `hhi_index` not strongly correlated with churn directly but useful context.
- No features show near-constant values (no useless variables).
