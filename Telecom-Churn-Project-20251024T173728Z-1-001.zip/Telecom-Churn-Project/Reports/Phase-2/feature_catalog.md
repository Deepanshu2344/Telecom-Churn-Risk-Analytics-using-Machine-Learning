
# Feature Catalog

1. pct_change
   - Definition: Month-over-month % change in subscribers for operator × circle.
   - Rationale: Detects sudden drops or growth. Negative values indicate churn risk.

2. churn_flag
   - Definition: Binary churn flag (1 if drop >5% in a month).
   - Rationale: Quick signal for potential subscriber loss. Used as the primary churn target.

3. churn_severe
   - Definition: 1 if drop >5% for 3 consecutive months.
   - Rationale: Indicates persistent churn that requires strategic action.

4. churn_competitor
   - Definition: 1 if operator declines >5% while total circle grows.
   - Rationale: Strong signal that subscribers are moving to competitors.

5. value_lag1/3/6
   - Definition: Subscriber counts lagged by 1, 3, 6 months.
   - Rationale: Captures short, medium, long-term historical behavior.

6. roll_mean_3/6
   - Definition: 3- and 6-month rolling average of subscribers.
   - Rationale: Smooths out noise and shows underlying trend.

7. roll_std_3/6
   - Definition: 3- and 6-month rolling standard deviation.
   - Rationale: High volatility signals unstable subscriber base.

8. trend_slope_12
   - Definition: Linear trend slope over past 12 months.
   - Rationale: Positive = growth, negative = long-term decline.

9. market_share
   - Definition: Operator’s share of total circle subscribers.
   - Rationale: Shows relative strength and competitiveness.

10. rank_in_circle
    - Definition: Rank of operator by subscriber count in circle.
    - Rationale: Identifies market leaders vs. weaker players.

11. leader_gap
    - Definition: Difference between leader’s subscriber count and current operator.
    - Rationale: Large gap means weaker position; useful for risk analysis.

12. hhi_index
    - Definition: Market concentration (sum of squared market shares).
    - Rationale: Distinguishes competitive vs. monopolistic circles.

13. month_sin / month_cos
    - Definition: Seasonal encoding of month.
    - Rationale: Captures cyclic effects like festive promotions.

14. type_of_connection_
    - Definition: One-hot encoding for prepaid/postpaid/wireline/wireless.
    - Rationale: Behavior differs by connection type.
