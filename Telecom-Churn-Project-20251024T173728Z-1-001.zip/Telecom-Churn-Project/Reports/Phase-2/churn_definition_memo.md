
# Churn Definition Memo

## Final Operational Definition (Primary)
- Binary churn (`churn_flag`)**: A subscriber base decline >5% month-over-month for an operator × circle.
- Why: Balanced between catching significant drops and avoiding noise. Simple to interpret for business.

## Secondary Definitions
1. Sustained churn (`churn_severe`): Decline >5% for 3 consecutive months.
   - Why: Captures long-term, structural subscriber losses.

2. Competitor churn (`churn_competitor`): Operator decline >5% while circle total grows.
   - Why: Indicates switching to competitors, crucial for strategic action.

## Trade-off Rationale
- Too strict (>10%): Misses churn events, fewer positive cases.
- Too lenient (<2%): Captures noise, more false positives, wasted interventions.
- Chosen 5% as a business-reasonable middle ground.

## Stakeholder Actionability
- If `churn_flag = 1`: Immediate local retention campaign.
- If `churn_severe = 1`: Escalate to management for strategic fix.
- If `churn_competitor = 1`: Allocate marketing spend vs. rival in that circle.
