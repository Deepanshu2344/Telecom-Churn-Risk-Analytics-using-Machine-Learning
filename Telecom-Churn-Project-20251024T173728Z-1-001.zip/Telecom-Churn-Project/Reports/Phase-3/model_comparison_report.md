
# Model Comparison Report — Phase 3

| Model | AUC | Precision | Recall | F1 |
|-------|------|------------|--------|----|
| Logistic Regression | 0.835 | 0.223 | 0.892 | 0.357 |
| Random Forest | 0.877 | 0.546 | 0.628 | 0.584 |
| CatBoost | 0.874 | 0.534 | 0.599 | 0.565 |

---

### Selected Model: Random Forest Classifier

Rationale:
- Delivers balanced trade-off between AUC (≈0.877), Precision (≈0.546), and Recall (≈0.628).
- Provides interpretability through feature importance while maintaining strong predictive power.
- Handles nonlinear relationships and interactions effectively across regions and operators.
- Less sensitive to outliers and noise than logistic regression.
- Simpler to deploy and monitor than boosting-based models like CatBoost.

Business Impact:
- Reliable for early churn detection at market level.
- Supports targeted interventions for circles and operators showing subscriber decline.
- Reduces resource waste on false alarms while keeping recall high for genuine churn risks.
