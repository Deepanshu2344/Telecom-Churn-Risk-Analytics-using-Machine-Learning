
# Interpretability Summary — Random Forest Model

## Top 10 Most Important Features

| Rank | Feature        | Importance Score |
|------|----------------|------------------|
| 1 | market_share    | 0.1126 |
| 2 | value           | 0.1113 |
| 3 | trend_slope_12  | 0.0938 |
| 4 | value_lag1      | 0.0723 |
| 5 | roll_mean_3     | 0.0616 |
| 6 | roll_mean_6     | 0.0553 |
| 7 | roll_std_6      | 0.0481 |
| 8 | rank_in_circle  | 0.0422 |
| 9 | year            | 0.0410 |
|10 | roll_std_3      | 0.0402 |

---

### Global Explanation (Overall Drivers)

- market_share: Strongest predictor. Operators with lower or declining share show higher churn risk.
- value: Represents total subscribers. Rapid drops in absolute value trigger early churn signals.
- trend_slope_12: Negative slope reflects consistent decline in subscribers across 12 months — a long-term churn pattern.
- value_lag1: Drop compared to previous month shows immediate churn risk.
- roll_mean_3 / roll_mean_6: Capture short-term and medium-term momentum; declining averages indicate sustained losses.
- roll_std_6 / roll_std_3: High volatility implies unstable customer behavior, often preceding churn.
- rank_in_circle: Lower rank (higher number) means the operator is weaker in that region’s market.
- year: Captures evolving market conditions or regulatory effects over time.

---

### Local Explanation Example

For a high-risk operator-circle in Maharashtra (2018):
- market_share: Dropped from 0.25 to 0.18 → customers moving to competitors.
- trend_slope_12: -0.8 → steady decline across 12 months.
- roll_std_6: High → subscriber counts fluctuate abnormally.

Interpretation:
“Declining market share combined with long-term negative trend and high volatility indicates competitive pressure and weak retention in this circle.”

---

### Business Takeaways

- Prioritize retention in circles showing negative trend_slope_12 and low market_share.
- Circles with high roll_std_6 or roll_std_3 reflect customer instability — focus on service quality and complaint resolution.
- Operators with low rank_in_circle should be targeted for marketing boosts and incentive plans.
- Use roll_mean_3 and roll_mean_6 as early warning indicators to prevent future churn.
- The year effect suggests including seasonality or policy changes in future model updates.

---

### Conclusion
The Random Forest model highlights market share dynamics, trend consistency, and subscriber volatility as the primary churn drivers.
This interpretability ensures that business users can translate model outputs into clear, actionable retention strategies.
