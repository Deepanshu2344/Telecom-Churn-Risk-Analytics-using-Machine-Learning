
# Risk Playbook — Based on Random Forest Model

## 1. High-Risk Segments
Indicators:
- trend_slope_12 < 0 (long-term subscriber decline)
- market_share < 0.15 (weak operator position)
- roll_std_6 / roll_std_3 high (high subscriber volatility)
- rank_in_circle > median (operator weaker in region)

Recommended Actions:
- Launch targeted retention campaigns in these circles.
- Conduct competitor benchmarking to understand churn drivers.
- Improve network quality, service reliability, and complaint resolution.
- Consider incentive plans for vulnerable subscribers.

---

## 2. Medium-Risk Segments
Indicators:
- Slight decline in trend_slope_12
- Moderate roll_std_6 (some volatility)
- market_share stable but lower than top competitors

Recommended Actions:
- Implement customer engagement and loyalty programs.
- Run regional promotions to prevent early churn.
- Monitor short-term momentum using roll_mean_3 and roll_mean_6.

---

## 3. Low-Risk Segments
Indicators:
- trend_slope_12 ≥ 0 (stable or growing subscribers)
- market_share ≥ 0.15
- rank_in_circle low (strong regional position)
- Low roll_std_6 / roll_std_3 (stable behavior)

Recommended Actions:
- Maintain service excellence and brand campaigns.
- Use as benchmark circles for best-practice replication.
- Monitor for emerging negative trends early.

---

### Summary
The Random Forest model identifies churn risk based on market share, trend slopes, volatility, and regional rank:
- Rank operator–circle pairs by predicted churn probability.
- Focus top-risk segments for immediate retention actions.
- Allocate marketing and operational resources efficiently.
- Use early-warning indicators (trend_slope_12, roll_mean/roll_std) to proactively reduce churn.
